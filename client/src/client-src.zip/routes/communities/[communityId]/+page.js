export const load = ({ params }) => {
  return {
    communityId: params.communityId
  };
};