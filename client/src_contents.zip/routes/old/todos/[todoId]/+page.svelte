<script>
  let { data } = $props();

  
  import Todo from '$lib/components/todos/Todo.svelte';

</script>

<!--
<h1>Todo {data.todoId}</h1>

<p>Todo {data.todoId}</p>

<p>Current Todo id: {data.todoId}</p>
<p>Next Todo id: {parseInt(data.todoId) + 1}</p>


<a href="/todos/{data.todoId}/tasks/1">Go to first task</a>
<p><a href={`/todos/${parseInt(data.todoId) + 1}`}>Go to next todo</a></p>
-->

<h1>Todo Details</h1>
<Todo todoId={data.todoId} />
