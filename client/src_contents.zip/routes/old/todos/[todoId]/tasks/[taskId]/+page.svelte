<script>
  let { data } = $props();
  import Task from '$lib/components/todos/Task.svelte';
</script>

<!--
<h1>Todo {data.todoId}, task {data.taskId}</h1>
<p>todo {data.todoId}, task {data.taskId}</p>

<a href={`/todos/${data.todoId}`}>Back to todo</a>


{#if data.taskId === "2"}
  <p>Task is number 2</p>
{:else}
  <p>Task is not number 2</p>
{/if}

-->

<Task todoId={data.todoId} taskId={data.taskId} />
