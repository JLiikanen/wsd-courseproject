<script>

  import AddTodo from "$lib/components/todos/AddTodo.svelte";
  import TodoList from "$lib/components/todos/TodoList.svelte";
</script>


<TodoList />
<AddTodo />
