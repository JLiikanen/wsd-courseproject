<script>
    let { todoId } = $props();

    import TaskList from '$lib/components/todos/TaskList.svelte';
    import { useTodosState } from '$lib/states/todoState.svelte';
    const todosState = useTodosState();

</script>

<h1>Todo {todosState.getOne(parseInt(todoId))?.name || "No todo"}</h1>
<TaskList todoId={todoId} />