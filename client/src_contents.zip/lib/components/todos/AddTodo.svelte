<script>
  import { useTodosState } from "$lib/states/todoState.svelte.js";
  let todosState = useTodosState();

  let todoName = $state("");
  const addTodo = () => {
    todosState.addTodo(todoName);
    todoName = "";
  };
</script>

<input type="text" bind:value={todoName} placeholder="Todo name" />
<button onclick={addTodo}>Add Todo</button>
