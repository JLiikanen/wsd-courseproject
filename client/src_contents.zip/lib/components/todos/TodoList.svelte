<script>


import { useTodosState } from "$lib/states/todoState.svelte";
const todosState = useTodosState();
console.log(todosState.todos);

</script>

<h1>Todos</h1>

<ul>
{#each todosState.todos as todo}
    <li><a href="/todos/{todo.id}">{todo.name}</a>
    <button onclick={() => todosState.removeTodo(todo.id)}>Remove</button>
    </li>
{/each}
</ul>