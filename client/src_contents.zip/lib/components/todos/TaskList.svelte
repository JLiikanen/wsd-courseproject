<script>
    let {todoId}  = $props();
  
    import { useTasksState } from "$lib/states/taskState.svelte.js";
    let tasksState = useTasksState();


   import AddTask from "$lib/components/todos/AddTask.svelte";
</script>

<h2>Tasks for Todo {parseInt(todoId)}</h2>
<ul>
{#each tasksState.tasks[parseInt(todoId)] as task}
    <li><a href="/todos/{todoId}/tasks/{task.id}">{task.name}</a>
    <button onclick={() => tasksState.removeTask(parseInt(todoId), task.id)}>Remove</button>
    </li>
{/each}
</ul>
<AddTask {todoId} />

