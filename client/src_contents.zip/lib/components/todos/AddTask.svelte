
<script>
    let { todoId } = $props();
    let taskName = $state("")
    import { useTasksState } from "$lib/states/taskState.svelte.js";
    let taskState = useTasksState();

    const addTask = () => {
        taskState.addTask(todoId, taskName);
        taskName = "";
    }

</script>


<input type="text" bind:value={taskName} placeholder="Task name" />
<button onclick={addTask}>Add Task</button>


