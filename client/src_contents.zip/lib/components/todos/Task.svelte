<script>
    let { todoId, taskId } = $props();

    import { useTasksState } from '$lib/states/taskState.svelte';
    const tasksState = useTasksState();

    import { useTodosState } from '$lib/states/todoState.svelte';
    const todosState = useTodosState();

    let todo = todosState.getOne(parseInt(todoId));
    let task = tasksState.tasks[parseInt(todoId)]?.find((c) => c.id === parseInt(taskId));
</script>

<h1>
  {#if !todo}
    Loading todo...
  {:else if (!task)}
    Todo {todo.id}: Task not found
  {:else}
    {todo.name}, {task.name}
  {/if}
</h1>