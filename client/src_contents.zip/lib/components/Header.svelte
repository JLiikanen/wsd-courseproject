<script>
    export let title = "Walking Skeleton";
    export let links = [
        { href: "/", label: "Home" },
        { href: "/about", label: "About" },
        { href: "/contact", label: "Contact" }
    ];

    let mobileOpen = false;
    const toggleMobile = () => (mobileOpen = !mobileOpen);
    const closeMobile = () => (mobileOpen = false);
</script>

<header class="header" role="banner">
    <div class="container">
        <div class="brand">
            <a href="/" class="logo" aria-label={title}>
                <!-- Replace with an <img> if you have a logo
                         <img src="/logo.png" alt="{title} logo" /> -->
                <strong>{title}</strong>
            </a>
        </div>

        <button
            class="mobile-toggle"
            aria-controls="main-nav"
            aria-expanded={mobileOpen}
            on:click={toggleMobile}
            aria-label="Toggle navigation">
            <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
        </button>

        <nav id="main-nav" class:open={mobileOpen} role="navigation" aria-label="Main navigation">
            <ul>
                {#each links as link}
                    <li><a href={link.href} on:click={closeMobile}>{link.label}</a></li>
                {/each}
            </ul>
        </nav>

        <div class="actions">
            <slot name="actions" />
        </div>
    </div>
</header>

<style>
    :global(body) { margin: 0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; }

    .header {
        background: var(--header-bg, #ffffff);
        border-bottom: 1px solid rgba(0,0,0,0.06);
        position: sticky;
        top: 0;
        z-index: 40;
    }

    .container {
        max-width: 1100px;
        margin: 0 auto;
        padding: 0.5rem 1rem;
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .brand .logo {
        text-decoration: none;
        color: inherit;
        display: inline-flex;
        align-items: center;
    }

    .mobile-toggle {
        background: none;
        border: none;
        display: none;
        padding: 0.25rem;
        margin-left: auto;
        cursor: pointer;
        color: inherit;
    }

    nav {
        margin-left: auto;
    }

    nav ul {
        list-style: none;
        display: flex;
        gap: 1rem;
        padding: 0;
        margin: 0;
        align-items: center;
    }

    nav a {
        text-decoration: none;
        color: inherit;
        padding: 0.5rem 0.6rem;
        border-radius: 6px;
    }

    nav a:hover,
    nav a:focus {
        background: rgba(0,0,0,0.03);
        outline: none;
    }

    .actions {
        margin-left: 0.5rem;
        display: flex;
        gap: 0.5rem;
        align-items: center;
    }

    /* Responsive: collapse to mobile */
    @media (max-width: 768px) {
        .mobile-toggle { display: inline-flex; }

        nav {
            position: absolute;
            left: 0;
            right: 0;
            top: 100%;
            background: var(--header-bg, #ffffff);
            border-bottom: 1px solid rgba(0,0,0,0.06);
            transform-origin: top;
            transition: transform 150ms ease, opacity 150ms ease;
            transform: scaleY(0);
            opacity: 0;
            pointer-events: none;
        }

        nav.open {
            transform: scaleY(1);
            opacity: 1;
            pointer-events: auto;
        }

        nav ul {
            flex-direction: column;
            padding: 0.5rem;
            gap: 0.25rem;
        }

        .actions { display: none; } /* show actions in slot inside nav if needed on mobile */
    }
</style>