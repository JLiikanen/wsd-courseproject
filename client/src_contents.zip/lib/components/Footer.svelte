<footer>
  <p>Thanks for visiting!</p>
</footer>