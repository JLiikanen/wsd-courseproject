<script>

let todos = $state([
    { id: 1, text: "Learn Svelte", done: false },
    { id: 2, text: "Build a Svelte app", done: false }
]);

let newTodo = $state("");

const addTodo = () => {
    if (newTodo.trim() !== "") {
        todos = [...todos, { id: todos.length += 1, text: newTodo, done: false }];
        newTodo = "";
    }
    console.log(todos)
};

const markAsDone = (id) => {
		const todo = todos.find(t => t.id === id);
		if (todo) {
			todo.done = true; // ✅ direct mutation works
		}
        console.log(todos)
	}


</script>


<h1>Todos</h1>

<input type="text" bind:value={newTodo} />
<button onclick={addTodo}>Add</button>

<h2>Pending</h2>

<ul>
    {#each todos.filter(todo => !todo.done) as todo}    
        <li>
            {todo.text}
            <button onclick={() => markAsDone(todo.id)}>Mark as done</button>
        </li>   
    {/each}
</ul> 

<h2>Completed</h2>

   <ul>
{#each todos.filter(todo => todo.done) as todo}
    
    <li>{todo.text} (done)</li>
      
{/each}
</ul>

<a href="/todos/1">Open todo 1</a>

<a href="/todos/1/tasks/1">Open todo 1, task 1</a>